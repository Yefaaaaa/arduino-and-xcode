
//  Created by Yefa Mai on 07-10-2016.
//  Copyright (c) Yefa Mai. All rights reserved.
//

import UIKit
import CoreBluetooth
import QuartzCore



/// The option to add a \n to the end of the received message (to make it more readable)
enum ReceivedMessageOption: Int {
    case None,
         Newline
}

final class SerialViewController: UIViewController, UITextFieldDelegate, BluetoothSerialDelegate {

//MARK: IBOutlets
    
    @IBOutlet weak var mainTextView: UITextView!
    @IBOutlet weak var messageField: UITextField!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var barButton: UIBarButtonItem!
    @IBOutlet weak var navItem: UINavigationItem!


    
//MARK: Functions
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // init serial
        serial = BluetoothSerial(delegate: self)
        
        // UI
        mainTextView.text = ""
        reloadView()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(SerialViewController.reloadView), name: "reloadStartViewController", object: nil)
        
       
    }

    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
  
    
    func reloadView() {
        // in case we're the visible view again
        serial.delegate = self
        
        if serial.isReady {
            navItem.title = serial.connectedPeripheral!.name
            barButton.title = "Disconnect"
            barButton.tintColor = UIColor.redColor()
            barButton.enabled = true
        } else if serial.state == .PoweredOn {
            navItem.title = "Data Receiver"
            barButton.title = "Connect"
            barButton.tintColor = view.tintColor
            barButton.enabled = true
        } else {
            navItem.title = "Data Receiver"
            barButton.title = "Connect"
            barButton.tintColor = view.tintColor
            barButton.enabled = false
        }
    }
    
    func textViewScrollToBottom() {
        let range = NSMakeRange(NSString(string: mainTextView.text).length - 1, 1)
        mainTextView.scrollRangeToVisible(range)
    }
    

//MARK: BluetoothSerialDelegate
    
    func serialDidReceiveString(message: String) {
        // add the received text to the textView, optionally with a line break at the end
        var data : Int? = Int(message)
        
        
        mainTextView.text! += message
        let pref = NSUserDefaults.standardUserDefaults().integerForKey(ReceivedMessageOptionKey)
        if pref == ReceivedMessageOption.Newline.rawValue { mainTextView.text! += "\n" }
        textViewScrollToBottom()
    }
    
    func serialDidDisconnect(peripheral: CBPeripheral, error: NSError?) {
        reloadView()
    
        let hud = MBProgressHUD.showHUDAddedTo(view, animated: true)
        hud.mode = MBProgressHUDMode.Text
        hud.labelText = "Disconnected"
        hud.hide(true, afterDelay: 1.0)
    }
    
    func serialDidChangeState(newState: CBCentralManagerState) {
        reloadView()
        if newState != .PoweredOn {
            let hud = MBProgressHUD.showHUDAddedTo(view, animated: true)
            hud.mode = MBProgressHUDMode.Text
            hud.labelText = "Bluetooth turned off"
            hud.hide(true, afterDelay: 1.0)
        }
    }
    
 
    
//MARK: IBActions

    @IBAction func barButtonPressed(sender: AnyObject) {
        if serial.connectedPeripheral == nil {
            performSegueWithIdentifier("ShowScanner", sender: self)
        } else {
            serial.disconnect()
            reloadView()
        }
    }
}